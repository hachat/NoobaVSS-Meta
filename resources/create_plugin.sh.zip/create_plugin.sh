#################################################################################
#                                                                               #
#    @section LICENSE                                                           #
#    Nooba Plugin API source file                                               #
#    Copyright (C) 2013 Developed by Team Nooba                                 #
#                                                                               #
#    This program is free software: you can redistribute it and/or modify       #
#    it under the terms of the GNU General Public License as published by       #
#    the Free Software Foundation, either version 3 of the License, or          #
#    (at your option) any later version.                                        #
#                                                                               #
#    This program is distributed in the hope that it will be useful,            #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of             #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              #
#    GNU General Public License for more details.                               #
#                                                                               #
#    You should have received a copy of the GNU General Public License          #
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.      #
#                                                                               #
#    @author  Chathuranga Hettiarachchi <chathuranga.09@cse.mrt.ac.lk>          #
#    @updated by Asitha Nanayakkara <asithan.09@cse.mrt.ac.lk>                  #
#                                                                               #
################################################################################# 

#!/usr/bin/env bash
if [ $# -eq 0 ]
  then
    echo "Give a name for the plugin. ./create_plugin.sh <plugin_name> is expected"
    echo " "
    echo "      example: ./create_plugin.sh test"
    echo " "
    echo "This will create a plugin called TestPlugin in plugins/nooba-plugin-test/ directory"
    echo " "
    exit -1  
fi

if [ -d nooba-plugin-template]; then
    rm -r nooba-plugin-template;
fi

git clone https://github.com/Asitha/nooba-plugin-template.git

plugin_name="$1"

TEMPLATE="TEMPLATE"
template="template"
Template="Template"

PLUGIN_NAME="${plugin_name^^}"
plugin_name="${plugin_name,,}"
Plugin_name="${plugin_name^}"

mv ./nooba-plugin-template $(echo "nooba-plugin-template" | sed "s/$template/$plugin_name/g") > /dev/null 2>&1

cd ./$(echo "nooba-plugin-template" | sed "s/$template/$plugin_name/g")

#changing directories
for i in 1 2 3; do
	for f in $(find -type d -not -path "*/.git*"); do

  		mv $f $(echo "$f" | sed "s/$TEMPLATE/$PLUGIN_NAME/g") > /dev/null 2>&1
  		mv $f $(echo $f | sed "s/$template/$plugin_name/g") > /dev/null 2>&1
  		mv $f $(echo $f | sed "s/$Template/$Plugin_name/g") > /dev/null 2>&1

	done
done

#changing filenames
for i in 1 2 3; do
	for f in $(find -type f -not -path "*/.git*"); do

  		mv $f $(echo $f | sed "s/$TEMPLATE/$PLUGIN_NAME/g") > /dev/null 2>&1
  		mv $f $(echo $f | sed "s/$template/$plugin_name/g") > /dev/null 2>&1
  		mv $f $(echo $f | sed "s/$Template/$Plugin_name/g")> /dev/null 2>&1
	done
done

#changing file content
for i in 1 2 3; do
	for f in $(find -type f -not -path "*/.git*"); do

  		sed -i "s/$TEMPLATE/$PLUGIN_NAME/g" $f > /dev/null 2>&1
  		sed -i "s/$template/$plugin_name/g" $f > /dev/null 2>&1
  		sed -i "s/$Template/$Plugin_name/g" $f > /dev/null 2>&1
	done
done

#restoring TEMPLATE keyword at the template of the project library

sed -i "s/$PLUGIN_NAME = lib/$TEMPLATE = lib/g" $(echo "./TemplatePlugin/TemplatePlugin.pro" | sed "s/$Template/$Plugin_name/g") > /dev/null 2>&1

#changing TARGET name
sed -i "s/TARGET = TestPlugin/TARGET = ${Plugin_name}Plugin/g" $(echo "./TemplatePlugin/TemplatePlugin.pro" | sed "s/$Template/$Plugin_name/g") > /dev/null 2>&1


chown $USER -R ./*

echo "updating the git repository for the new plugin"

git rm TemplatePlugin*
git add .
git commit -m "initial commit of nooba-plugin-$plugin_name"
git remote rm origin

exit 0
